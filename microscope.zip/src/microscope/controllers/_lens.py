from .._base import Base
from .._utils import *
from ... import validation

if ONLINE:
    from PyJEM.TEM3 import Lens3
else:
    from PyJEM.offline.TEM3 import Lens3

lens = validation.Pipeline.enum(Lens)


class Controller(Base):

    @Key
    def current(self) -> Lens:
        return self._current

    @current.setter
    def current(self, value: Lens):
        lens.validate(value)
        self._current = value

    @Key
    def value(self) -> int:
        if self._current == Lens.CL1:
            return self._controller.GetCL1()
        elif self._current == Lens.CL2:
            return self._controller.GetCL2()
        elif self._current == Lens.CL3:
            return self._controller.GetCL3()
        elif self._current == Lens.CM:
            return self._controller.GetCM()
        elif self._current == Lens.OL_COARSE:
            return self._controller.GetOLc()
        elif self._current == Lens.OL_FINE:
            return self._controller.GetOLf()
        elif self._current == Lens.OM1:
            return self._controller.GetOM()
        elif self._current == Lens.OM2:
            return self._controller.GetOM2()
        elif self._current == Lens.IL1:
            return self._controller.GetIL1()
        elif self._current == Lens.IL2:
            return self._controller.GetIL2()
        elif self._current == Lens.IL3:
            return self._controller.GetIL3()
        elif self._current == Lens.IL4:
            return self._controller.GetIL4()
        elif self._current == Lens.PL1:
            return self._controller.GetPL1()
        elif self._current == Lens.PL2:
            return self._controller.GetPL2()
        elif self._current == Lens.PL3:
            return self._controller.GetPL3()
        elif self._current == Lens.FL_COARSE:
            return self._controller.GetFLc()
        elif self._current == Lens.FL_FINE:
            return self._controller.GetFLf()

    def __init__(self, current: Lens):
        super().__init__("Lenses")
        self._controller = Lens3()
        self._current = current

    switch_lens = current.switch
